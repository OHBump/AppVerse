import React from "react";
import db from "./db.js";
import Bot from "./Bot.js";
import BotCard from "./BotCard.js";
import LanguageSwitcher from "./LanguageSwitcher.js";
import SupportServerButton from "./SupportServerButton.js";
import SearchBar from "./SearchBar.js";

export async function getServerSideProps(context) {
  await db();
  const bots = await Bot.find({});
  return { props: { bots: JSON.parse(JSON.stringify(bots)) } };
}

export default function Home({ bots }) {
  const [query, setQuery] = React.useState("");
  const filteredBots = bots.filter(
    bot =>
      bot.name.toLowerCase().includes(query.toLowerCase()) ||
      bot.description.toLowerCase().includes(query.toLowerCase()) ||
      bot.category.join(",").toLowerCase().includes(query.toLowerCase())
  );

  return (
    <main style={{ maxWidth: "1100px", margin: "0 auto", padding: "32px 0" }}>
      <header style={{ marginBottom: "26px", display: "flex", alignItems: "center" }}>
        <img src="logo.png" alt="AppVerse Logo" style={{ width: 58, borderRadius: "16px" }} />
        <h1 style={{ marginLeft: "22px" }}>AppVerse</h1>
        <LanguageSwitcher />
        <SupportServerButton />
      </header>
      <SearchBar onSearch={setQuery} />
      <section style={{ display: "flex", flexWrap: "wrap", gap: "28px", justifyContent: "center", marginTop: "22px" }}>
        {filteredBots.length === 0
          ? <div>No bots found for "{query}"</div>
          : filteredBots.map(bot => <BotCard key={bot._id} bot={bot} />)}
      </section>
      <footer style={{ textAlign: "center", margin: "54px 0 0", color: "#888" }}>
        &copy; 2026 AppVerse | <a href="#tos">ToS</a> | <a href="#privacy">Privacy</a>
      </footer>
    </main>
  );
}