import React from "react";
export default function BotCard({ bot }) {
  return (
    <div style={{
      boxShadow: '0 1px 6px #bbb',
      padding: 18,
      borderRadius: 12,
      width: 270,
      background: '#fff',
      marginBottom: 24
    }}>
      <img src={bot.avatar} alt={bot.name} width={54} height={54} style={{ borderRadius: '14px' }} />
      <h2>{bot.name}</h2>
      <p>{bot.description}</p>
      <p><b>Category:</b> {bot.category.join(', ')}</p>
      <a href={bot.invite} target="_blank" rel="noopener noreferrer">Invite Bot</a>
      <span> | </span>
      <a href={`/bots/${bot._id}`}>Details</a>
    </div>
  );
}